return {
    'lunarvim/horizon.nvim',
    config = function()
        vim.cmd.colorscheme 'horizon'
        vim.cmd.hi 'Comment gui=none'
        end
}

