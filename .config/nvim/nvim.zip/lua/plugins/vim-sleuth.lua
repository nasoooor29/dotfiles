return {
    'tpope/vim-sleuth'
}
